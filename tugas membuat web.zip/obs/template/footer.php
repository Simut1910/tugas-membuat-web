      	<hr>

      	<footer class="fixed-bottom bg-light bg-gradient border py-3 px-2">
			<div class="container">
				<div class="d-flex justify-content-between">
					<div class="">
						<a href="https://sourcecodester.com" target="_blank" class="text-decoration-none text-muted fw-bold"> MyNovel &copy; <?= date('Y') ?> </a>
					</div>
					<div class="">
						<a href="admin.php" class="text-decoration-none text-dark fw-bolder">Login as Admin</a>
					</div>
				</div>
			</div>
      	</footer>
		<div class="clear-fix py-4"></div>
    </div> <!-- /container -->

  </body>
</html>