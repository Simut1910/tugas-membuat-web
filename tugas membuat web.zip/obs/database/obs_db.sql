-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 31 Agu 2022 pada 05.49
-- Versi server: 10.4.17-MariaDB
-- Versi PHP: 7.3.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `obs_db`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `admin`
--

CREATE TABLE `admin` (
  `name` varchar(20) NOT NULL,
  `pass` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `admin`
--

INSERT INTO `admin` (`name`, `pass`) VALUES
('123', '123');

-- --------------------------------------------------------

--
-- Struktur dari tabel `books`
--

CREATE TABLE `books` (
  `book_isbn` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `book_title` varchar(60) COLLATE latin1_general_ci DEFAULT NULL,
  `book_author` varchar(60) COLLATE latin1_general_ci DEFAULT NULL,
  `book_image` varchar(40) COLLATE latin1_general_ci DEFAULT NULL,
  `book_descr` text COLLATE latin1_general_ci DEFAULT NULL,
  `book_price` decimal(6,2) NOT NULL,
  `publisherid` int(10) UNSIGNED NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Dumping data untuk tabel `books`
--

INSERT INTO `books` (`book_isbn`, `book_title`, `book_author`, `book_image`, `book_descr`, `book_price`, `publisherid`, `created_at`) VALUES
('20003', 'Bintang The Loli Hunter', 'M Rafi Pardono', 'Bintang.jpeg', 'Bintang Hunter', '10.00', 3, '2022-08-19 08:53:38'),
('2004', 'Aku Mas Udin VS Pesulap Merah', 'Udin And Pesulap', 'Udin.jpeg', 'Kisah ini menceritakan tentang dukun yang bernama sam udin dengan pesulap merah Atas Ilmu Santetnya!!!!!', '9999.99', 1, '2022-08-19 08:22:34'),
('22245', 'ab223', 'asd', 'Udin.jpeg', 'hdddf', '1125.00', 5, '2022-08-24 10:56:26'),
('33441', 'The Immortal’s Poison', 'M Rafi Pardono', 'the-immortal-s-poison.webp', 'Ini adalah kisah pemuda Wen Leyang, lahir dalam keluarga dengan keahlian dalam pengembangan Seni Racun.\r\n\r\nMusuh mungkin tidak selalu jahat, dan orang jahat juga tidak selalu menjadi musuh. Namun, satu hal yang pasti. Wen Leyang adalah pria muda yang jujur ??dan jujur, pahlawan yang menyenangkan yang memiliki sifat baik terhadap makhluk hidup apa pun.\r\n\r\nPelajari tentang perjalanannya saat ia memulai petualangan mengolah menjadi abadi.', '10.00', 6, '2022-08-12 08:41:07'),
('3344122', 'Udin Si Petualang', 'Gus Sam Udin', 'kotlin_250x250.png', 'Aku Udin!!!!!!!!!!!!!!!!!!!!!!!', '0.01', 5, '2022-08-19 07:53:55'),
('64568', 'Great Voyage: the Strongest Clone System', 'break through sky k', 'dark-bg1.webp', 'Perjalanan ke dunia bajak laut dan jadilah putra angkat Belmer! Kakak Nami dan Nokigo! Liu Ye, telah menanam jeruk selama lima tahun!\r\n\r\nSuatu hari, Liu Ye, yang tiba-tiba menyadari bahwa dia tidak bisa terus seperti ini, dengan mentalitas mencoba, bermeditasi di dalam hatinya: “Sistem?”\r\n\r\n“Saya di sini.” Suara lucu seperti teman sekelas Xiao Ai berdering.\r\n\r\nBangunkan sistem klon terkuat! Setiap kali Anda naik level, Anda bisa mendapatkan klon!\r\n\r\nLoyalitas mutlak, tidak takut mati, dan mampu meningkatkan melalui pertempuran, meningkatkan atribut, dan bahkan langsung membeli berbagai kemampuan magis yang berlebihan!\r\n\r\n“Sejujurnya, markas angkatan laut, kaisar laut dari dunia baru, penguasa dunia bawah tanah, dan bahkan para pemimpin tertinggi cp0 dan tentara revolusioner, memiliki orang-orangku.”\r\n\r\nSebelum perang di Wano, Liu Yejin memegang tangan Nami secara misterius, dan berkata kepada Nami, “Jangan takut, tidak ada yang berani menyentuhmu dengan dukungan saudaramu.”', '12.00', 6, '2022-06-21 16:44:25'),
('978-0-321-94786-4', 'Empress: My Husband Killed The Immortal Emperor After 10 Yea', 'M.Mahmud', 'mobile_app.webp', 'Li Xuan melakukan perjalanan melalui dunia keabadian dan membuka sistem magang, dan magang dan magang dapat diberi hadiah untuk peningkatan.\r\n\r\nLi Xuan, yang menerima sekelompok murid, berkembang tanpa batas dalam pengasingan.\r\n\r\nSepuluh tahun kemudian, Kaisar Iblis menyerbu dan ingin mengorbankan seluruh dunia, tetapi tidak ada yang bisa menghentikannya. Para murid menyaksikan dunia jatuh dalam keputusasaan dalam kesakitan.\r\n\r\nPada saat ini, Li Xuan muncul dan mengayunkan pedang ke arah Kaisar Iblis di bawah pengawasan publik.\r\n\r\nBoom!\r\n\r\nLangit runtuh, Kaisar Iblis yang tak terkalahkan jatuh di tempat, dan seluruh dunia gelap tersapu oleh pedang.\r\n\r\nPara murid ketakutan. Ternyata orang terkuat di dunia sebenarnya adalah master yang telah mengasingkan diri selama sepuluh tahun.', '20.00', 6, '2022-06-21 16:44:25'),
('978-0-7303-1484-4', 'The Strongest Player: Infinite Future', 'Peter Baines', 'doing_good.webp', 'Setelah menonton pertandingan pensiunan Black Mamba, Yu Huo memenangkannya. Dia mewarisi mantel Black Mamba dan memimpin kembali pasukan ungu dan emas ke puncak.', '10.00', 2, '2022-06-21 16:44:25'),
('978-1-118-94924-5', 'This Option is Fantastic', 'Dag H. Hanssen', 'logic_program.webp', 'Segel waktu dan ruang di dimensi yang berbeda rusak, makhluk dari berbagai ras menyerbu, iblis dan binatang buas menyapu langit, kota jatuh, dan umat manusia berada dalam krisis!', '20.00', 2, '2022-06-21 16:44:25'),
('978-1-1180-2669-4', 'I Get Stronger When I Rest', 'Nicholas C. Zakas', 'pro_js.webp', 'Shen Xuan, lulusan baru Universitas Suzhou, mendapatkan sistem, dan dia bisa menjadi lebih kuat setelah istirahat.\r\n\r\nIstirahat selama sepuluh menit dan dapatkan edisi terbatas super run senilai 50 juta Bugatti.\r\n\r\nSetelah beristirahat selama satu jam, dia dikejar oleh pengawal tertua dari semua lapisan masyarakat.\r\n\r\nIstirahat selama dua jam, selamat, jadilah orang terkaya di Suzhou dan Hangzhou. …\r\n\r\nIstirahat selama n jam, sistem, apa lagi yang tidak saya dapatkan?', '20.00', 1, '2022-06-21 16:44:25'),
('978-1-44937-019-0', 'The Engineering Boss', 'Semmy Purewal', 'web_app_dev.webp', '“Pasang lift untuk puncak tertinggi dunia, bukan?”\r\n\r\n“Lakukan, mengapa tidak!”\r\n\r\n“Selama ada dana, Anda mengizinkan saya mengenakan kacamata hitam!”\r\n\r\n……\r\n\r\nIni adalah kisah seorang pemuda yang terlahir kembali di dunia paralel untuk menjadi bos teknik!', '20.00', 3, '2022-06-21 16:44:25'),
('978-1-44937-075-6', 'King of Stage', 'Bapak XCO-Pancing', 'beauty_js.webp', 'Saat nada mengalir perlahan, kegelapan menghilang;\r\n\r\nSaat saya berdiri di atas panggung dengan kaki saya, saya adalah raja dunia.', '20.00', 3, '2022-06-21 16:44:25'),
('978-1-4571-0402-2', 'Seventy Koi: The Unlucky Boss Hugged Me and Cried', 'Bapak Kentang Sudrajat', 'pro_asp5.webp', 'Dia, Mu Qing, memegang perlengkapan luar angkasa dan berpakaian seperti gadis desa yang konyol.\r\n\r\nAwalnya sulit bagi semua orang, dan itu masih satu wanita vs dua pria.\r\n\r\nDalam menghadapi adegan penangkapan yang akan datang, dia dengan tegas melepaskan tujuan yang ditetapkan oleh kerabatnya dan berbalik ke pelukan bos yang tidak beruntung.\r\n\r\nMulai sekarang, dia akan berjuang untuk yang terbaik, mencari keadilan, dan membersihkan semua orang yang ingin menyakitinya.\r\n\r\nOmong-omong… Oh tidak, bagaimana nasib bos sial ini bisa lebih baik, dan dia masih memeluknya dan menangis di tengah malam?\r\n\r\n', '20.00', 1, '2022-06-21 16:44:25'),
('978-1-484216-40-8', 'Demon’s Diary', 'Wang Yu', 'android_studio1.webp', 'Liu Ming, sejak ia masih muda, tinggal di penjara buas bernama Pulau Savage di mana para tahanan tidak dikendalikan oleh penjaga atau keamanan apa pun. Ketika pulau itu tenggelam karena peristiwa \"misterius\", hanya segelintir orang yang selamat - mereka yang selamat kemudian dikejar oleh pemerintah.\r\n\r\nDi sisi lain di tempat lain dua praktisi khawatir tentang apa yang akan terjadi pada mereka karena tuan muda yang seharusnya mereka lindungi telah meninggal.\r\n\r\nTuan muda mereka hampir mirip dengan MC kami\r\nApa yang akan terjadi?', '22.00', 6, '2022-06-21 16:44:25');

-- --------------------------------------------------------

--
-- Struktur dari tabel `customers`
--

CREATE TABLE `customers` (
  `customerid` int(10) UNSIGNED NOT NULL,
  `name` varchar(60) COLLATE latin1_general_ci NOT NULL,
  `address` varchar(80) COLLATE latin1_general_ci NOT NULL,
  `city` varchar(30) COLLATE latin1_general_ci NOT NULL,
  `zip_code` varchar(10) COLLATE latin1_general_ci NOT NULL,
  `country` varchar(60) COLLATE latin1_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Dumping data untuk tabel `customers`
--

INSERT INTO `customers` (`customerid`, `name`, `address`, `city`, `zip_code`, `country`) VALUES
(1, 'a', 'a', 'a', 'a', 'a'),
(2, 'b', 'b', 'b', 'b', 'b'),
(3, 'test', '123 test', '12121', 'test', 'test'),
(4, 'Mark Cooper', 'Sample Street', 'Here', '2306', 'Sampple'),
(5, 'Mark Cooper', 'Sample Street', 'Sample City', '2306', 'Philippines'),
(6, 'Mark Cooper', 'Here City There Province, 2306', 'Here', '2306', 'Philippines'),
(7, 'Mark Cooper', 'Here City There Province, 2306', 'Sample City', '2306', 'Philippines'),
(8, 'Samantha Jane Miller', 'Sample Street', 'Sample City', '2306', 'Sampple'),
(9, 'admin', '', '', '', ''),
(10, 'wesdgfh', '', '', '', ''),
(11, 'w', '', '', '', ''),
(12, 'nova', '21', 'salatiga', '123', 'indonesia'),
(13, 'nova', '12', 'salatiga', '123', 'indonesia'),
(14, 'e22', '2', 'kota', '222indo', 'ibdi'),
(15, 'f', '', '', '', ''),
(16, 'fcvb', '', '', '', ''),
(17, 'gh', '', '', '', ''),
(18, 'df', '', '', '', '');

-- --------------------------------------------------------

--
-- Struktur dari tabel `orders`
--

CREATE TABLE `orders` (
  `orderid` int(10) UNSIGNED NOT NULL,
  `customerid` int(10) UNSIGNED NOT NULL,
  `amount` decimal(6,2) DEFAULT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp(),
  `ship_name` char(60) COLLATE latin1_general_ci NOT NULL,
  `ship_address` char(80) COLLATE latin1_general_ci NOT NULL,
  `ship_city` char(30) COLLATE latin1_general_ci NOT NULL,
  `ship_zip_code` char(10) COLLATE latin1_general_ci NOT NULL,
  `ship_country` char(20) COLLATE latin1_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Dumping data untuk tabel `orders`
--

INSERT INTO `orders` (`orderid`, `customerid`, `amount`, `date`, `ship_name`, `ship_address`, `ship_city`, `ship_zip_code`, `ship_country`) VALUES
(1, 1, '60.00', '2015-12-03 13:30:12', 'a', 'a', 'a', 'a', 'a'),
(2, 2, '60.00', '2015-12-03 13:31:12', 'b', 'b', 'b', 'b', 'b'),
(3, 3, '20.00', '2015-12-03 19:34:21', 'test', '123 test', '12121', 'test', 'test'),
(4, 1, '20.00', '2015-12-04 10:19:14', 'a', 'a', 'a', 'a', 'a'),
(5, 4, '80.00', '2022-06-21 00:09:36', 'Mark Cooper', 'Sample Street', 'Here', '2306', 'Sampple'),
(6, 5, '220.00', '2022-06-21 01:35:16', 'Mark Cooper', 'Sample Street', 'Sample City', '2306', 'Philippines'),
(7, 6, '20.00', '2022-06-21 01:38:20', 'Mark Cooper', 'Here City There Province, 2306', 'Here', '2306', 'Philippines'),
(8, 7, '20.00', '2022-06-21 01:40:28', 'Mark Cooper', 'Here City There Province, 2306', 'Sample City', '2306', 'Philippines'),
(9, 8, '80.00', '2022-06-21 01:42:56', 'Samantha Jane Miller', 'Sample Street', 'Sample City', '2306', 'Sampple'),
(10, 9, '12.00', '2022-08-11 20:43:45', 'admin', '', '', '', ''),
(11, 10, '12.00', '2022-08-18 19:18:40', 'wesdgfh', '', '', '', ''),
(12, 11, '0.01', '2022-08-18 20:42:06', 'w', '', '', '', ''),
(13, 9, '10.00', '2022-08-18 20:47:20', 'admin', '', '', '', ''),
(14, 12, '9999.99', '2022-08-18 21:04:41', 'nova', '21', 'salatiga', '123', 'indonesia'),
(15, 13, '20.00', '2022-08-18 21:07:42', 'nova', '12', 'salatiga', '123', 'indonesia'),
(16, 14, '10.00', '2022-08-23 22:36:23', 'e22', '2', 'kota', '222indo', 'ibdi'),
(17, 15, '10.00', '2022-08-23 23:00:01', 'f', '', '', '', ''),
(18, 16, '9999.99', '2022-08-23 23:30:36', 'fcvb', '', '', '', ''),
(19, 17, '1135.00', '2022-08-23 23:37:04', 'gh', '', '', '', ''),
(20, 18, '10.00', '2022-08-25 22:52:09', 'df', '', '', '', '');

-- --------------------------------------------------------

--
-- Struktur dari tabel `order_items`
--

CREATE TABLE `order_items` (
  `orderid` int(10) UNSIGNED NOT NULL,
  `book_isbn` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `item_price` decimal(6,2) NOT NULL,
  `quantity` tinyint(3) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Dumping data untuk tabel `order_items`
--

INSERT INTO `order_items` (`orderid`, `book_isbn`, `item_price`, `quantity`) VALUES
(1, '978-1-118-94924-5', '20.00', 1),
(1, '978-1-44937-019-0', '20.00', 1),
(1, '978-1-49192-706-9', '20.00', 1),
(2, '978-1-118-94924-5', '20.00', 1),
(2, '978-1-44937-019-0', '20.00', 1),
(2, '978-1-49192-706-9', '20.00', 1),
(3, '978-0-321-94786-4', '20.00', 1),
(1, '978-1-49192-706-9', '20.00', 1),
(5, '978-1-4571-0402-2', '20.00', 2),
(5, '978-1-44937-075-6', '20.00', 1),
(5, '978-0-321-94786-4', '20.00', 1),
(6, '978-1-4571-0402-2', '20.00', 10),
(6, '978-1-44937-075-6', '20.00', 1),
(7, '978-0-7303-1484-4', '20.00', 1),
(8, '978-1-1180-2669-4', '20.00', 1),
(9, '978-1-44937-019-0', '20.00', 4),
(10, '64568', '12.00', 1),
(11, '64568', '12.00', 1),
(12, 'asd', '0.01', 1),
(10, '31222', '10.00', 1),
(14, '2776', '9999.99', 2),
(15, '20003', '10.00', 2),
(16, '20003', '10.00', 1),
(17, '20003', '10.00', 1),
(18, '978-1-4571-0402-2', '20.00', 1),
(18, '978-0-7303-1484-4', '10.00', 2),
(18, '2004', '9999.99', 3),
(18, '22245', '1125.00', 2),
(18, '20003', '10.00', 1),
(19, '5555', '10.00', 1),
(19, '22245', '1125.00', 1),
(20, '20003', '10.00', 1);

-- --------------------------------------------------------

--
-- Struktur dari tabel `publisher`
--

CREATE TABLE `publisher` (
  `publisherid` int(10) UNSIGNED NOT NULL,
  `publisher_name` varchar(60) COLLATE latin1_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Dumping data untuk tabel `publisher`
--

INSERT INTO `publisher` (`publisherid`, `publisher_name`) VALUES
(1, 'Publisher 1'),
(2, 'Publisher 2'),
(3, 'Publisher 3'),
(4, 'Publisher 4'),
(5, 'Publisher 5'),
(6, 'Publisher 6');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`name`,`pass`);

--
-- Indeks untuk tabel `books`
--
ALTER TABLE `books`
  ADD PRIMARY KEY (`book_isbn`);

--
-- Indeks untuk tabel `customers`
--
ALTER TABLE `customers`
  ADD PRIMARY KEY (`customerid`);

--
-- Indeks untuk tabel `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`orderid`);

--
-- Indeks untuk tabel `publisher`
--
ALTER TABLE `publisher`
  ADD PRIMARY KEY (`publisherid`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `customers`
--
ALTER TABLE `customers`
  MODIFY `customerid` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT untuk tabel `orders`
--
ALTER TABLE `orders`
  MODIFY `orderid` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT untuk tabel `publisher`
--
ALTER TABLE `publisher`
  MODIFY `publisherid` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
